package shapemaker.shape_list;

public enum ITERATE {
    FORWARD, BACK
}
