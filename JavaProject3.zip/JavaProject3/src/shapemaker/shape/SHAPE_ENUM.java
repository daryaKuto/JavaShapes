package shapemaker.shape;

public enum SHAPE_ENUM {
    DIAMOND, RECTANGLE, TRIANGLE
}
